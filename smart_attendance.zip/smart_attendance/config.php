<?php
// config.php

// --- DATABASE CONFIGURATION ---
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'smart_attendance_upgraded'; // Your database name

// --- ESTABLISH CONNECTION AND SELECT DATABASE ---
// THE FIX IS HERE: Added $DB_NAME as the fourth parameter.
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

// Check for connection errors. This is crucial.
if ($mysqli->connect_error) {
    // Use connect_error for modern PHP/MySQLi
    die("MySQL connection failed: " . $mysqli->connect_error);
}

// Start the session AFTER a successful connection.
session_start();

// --- HELPER FUNCTIONS ---

// Basic CSRF token helper
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Simple logger for audit trail
function audit_log($mysqli, $user_id, $action, $details='') {
    // It's safer to check if the connection is valid before using it in a function.
    if (!$mysqli) return;

    $stmt = $mysqli->prepare("INSERT INTO audit_log (user_id, action, details) VALUES (?,?,?)");
    if ($stmt) {
        $stmt->bind_param('iss', $user_id, $action, $details);
        $stmt->execute();
        $stmt->close(); // Good practice to close the statement
    }
}
?>