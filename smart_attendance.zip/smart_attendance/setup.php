<?php
require 'config.php';
// Prevent re-run
if (isset($_GET['run']) && $_GET['run']==='1') {
    // Create DB and tables
    $sqls = file_get_contents('init_db.sql');
    if (!$mysqli->multi_query($sqls)) {
        echo 'DB creation failed: ' . $mysqli->error;
        exit;
    }
    // wait for completion of multi_query
    while ($mysqli->more_results() && $mysqli->next_result()) {;}
    // Now connect to DB
    $mysqli->select_db('smart_attendance_upgraded');
    // Seed users with password_hash
    $pwd_admin = password_hash('admin123', PASSWORD_DEFAULT);
    $pwd_teacher = password_hash('teacher123', PASSWORD_DEFAULT);
    $pwd_student = password_hash('student123', PASSWORD_DEFAULT);
    $stmt = $mysqli->prepare("INSERT IGNORE INTO users (name,email,password,role) VALUES (?,?,?,?)");
    $r = $stmt->bind_param('ssss', $n, $e, $p, $role);
    $n='Admin User'; $e='admin@example.com'; $p=$pwd_admin; $role='admin'; $stmt->execute();
    $n='Teacher Tom'; $e='teacher@example.com'; $p=$pwd_teacher; $role='teacher'; $stmt->execute();
    $n='Student Sam'; $e='student@example.com'; $p=$pwd_student; $role='student'; $stmt->execute();
    // create student profile
    $stmt2 = $mysqli->prepare("INSERT IGNORE INTO students (user_id, name, email, roll_no, class_id) VALUES (?,?,?,?,?)");
    $class_id = 1;
    // find student user id
    $res = $mysqli->query("SELECT id FROM users WHERE email='student@example.com' LIMIT 1"); $uid = $res->fetch_assoc()['id'];
    $stmt2->bind_param('isssi', $uid, $nm, $em, $rn, $class_id);
    $nm='Student Sam'; $em='student@example.com'; $rn='S001'; $stmt2->execute();
    echo 'Setup completed. Please remove or secure setup.php';
    exit;
} else {
    echo '<h3>Run setup</h3><p>Click to run DB create and seed (will only run if ?run=1): <a href="?run=1">Run setup</a></p>';
}
?>