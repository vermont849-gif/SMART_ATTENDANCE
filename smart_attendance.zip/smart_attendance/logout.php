<?php
require 'config.php';
if (isset($_SESSION['user'])) {
    audit_log($mysqli, $_SESSION['user']['id'], 'logout', 'User logged out');
}
session_destroy();
header('Location: index.php'); exit;
?>