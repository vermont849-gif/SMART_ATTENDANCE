<?php
require 'config.php';
require 'inc/functions.php';
login_required();
$mysqli->select_db('smart_attendance_upgraded');
$res = $mysqli->query('SELECT s.*, c.name as class_name FROM students s LEFT JOIN classes c ON s.class_id=c.id ORDER BY roll_no');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Students</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light">
<div class="container py-4"><h4>Students</h4><table class="table"><thead><tr><th>Roll</th><th>Name</th><th>Email</th><th>Class</th></tr></thead><tbody><?php while($r=$res->fetch_assoc()): ?>
<tr><td><?php echo htmlspecialchars($r['roll_no']); ?></td><td><?php echo htmlspecialchars($r['name']); ?></td><td><?php echo htmlspecialchars($r['email']); ?></td><td><?php echo htmlspecialchars($r['class_name']); ?></td></tr>
<?php endwhile; ?></tbody></table></div></body></html>