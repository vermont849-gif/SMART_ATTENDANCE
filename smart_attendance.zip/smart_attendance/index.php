<?php
require 'config.php';
if (isset($_SESSION['user'])) header('Location: dashboard.php');
$error = isset($_GET['error']);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Smart Attendance - Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h3 class="card-title mb-3">Smart Attendance</h3>
          <?php if($error): ?><div class="alert alert-danger">Invalid credentials</div><?php endif; ?>
          <form method="post" action="login.php">
            <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(csrf_token()); ?>">
            <div class="mb-2"><label>Email</label><input class="form-control" name="email" required></div>
            <div class="mb-2"><label>Password</label><input type="password" class="form-control" name="password" required></div>
            <div class="mb-2"><label>Role</label>
              <select name="role" class="form-select"><option value="teacher">Teacher</option><option value="student">Student</option><option value="admin">Admin</option></select>
            </div>
            <button class="btn btn-primary">Login</button>
          </form>
        </div>
      </div>
      <p class="text-muted mt-2">Use seeded accounts via setup.php</p>
    </div>
  </div>
</div>
</body></html>