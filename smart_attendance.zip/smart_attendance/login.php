<?php
require 'config.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') { header('Location: index.php'); exit; }
if (!verify_csrf($_POST['csrf'] ?? '')) { die('Invalid CSRF'); }
$email = $_POST['email']; $password = $_POST['password']; $role = $_POST['role'];
$stmt = $mysqli->prepare('SELECT id,name,email,password,role FROM users WHERE email=? AND role=? LIMIT 1');
$stmt->bind_param('ss',$email,$role);
$stmt->execute(); $res = $stmt->get_result();
if ($res && $res->num_rows===1) {
    $u = $res->fetch_assoc();
    if (password_verify($password, $u['password'])) {
        // set session user array
        $_SESSION['user'] = ['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];
        audit_log($mysqli, $u['id'], 'login', 'User logged in');
        header('Location: dashboard.php');
        exit;
    }
}
header('Location: index.php?error=1');
?>