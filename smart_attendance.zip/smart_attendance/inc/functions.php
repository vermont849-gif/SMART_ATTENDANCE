<?php
require_once __DIR__ . '/../config.php';

function require_role($role) {
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== $role) {
        header('Location: /' . basename(__DIR__) . '/../index.php');
        exit;
    }
}

function login_required() {
    if (!isset($_SESSION['user'])) {
        header('Location: /index.php');
        exit;
    }
}

function current_user_id() {
    return isset($_SESSION['user']) ? $_SESSION['user']['id'] : null;
}
?>