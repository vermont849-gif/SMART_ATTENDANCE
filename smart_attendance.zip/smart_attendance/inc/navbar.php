<?php
// This file assumes that a session has already been started
if (!isset($_SESSION['user'])) {
    // Redirect to login if session is not set (for safety)
    header('Location: ../index.php');
    exit;
}
$user_role = $_SESSION['user']['role'];
$user_name = $_SESSION['user']['name'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <!-- You can replace text with an <img> tag for a logo -->
            <strong>Smart Attendance</strong>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                <?php if ($user_role === 'admin'): ?>
                    <li class="nav-item"><a class="nav-link" href="dashboard_admin.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="users.php">Manage Users</a></li>
                    <li class="nav-item"><a class="nav-link" href="classes.php">Manage Classes</a></li>
					<li class="nav-item"><a class="nav-link" href="roster.php">Class Rosters</a></li>
                <?php elseif ($user_role === 'teacher'): ?>
                    <li class="nav-item"><a class="nav-link" href="dashboard_teacher.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="mark_attendance.php">Mark Attendance</a></li>
                    <li class="nav-item"><a class="nav-link" href="analytics.php">Analytics</a></li>
                <?php elseif ($user_role === 'student'): ?>
                    <li class="nav-item"><a class="nav-link" href="dashboard_student.php">My Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="history.php">View History</a></li>
                    <li class="nav-item"><a class="nav-link" href="leave_request.php">Apply for Leave</a></li>
                <?php endif; ?>

            </ul>
            <span class="navbar-text me-3">
                Welcome, <?php echo htmlspecialchars($user_name); ?>
            </span>
            <a href="../logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>