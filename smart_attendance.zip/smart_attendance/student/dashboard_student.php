<?php
require '../config.php';
require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    header('Location: ../index.php');
    exit;
}

$user_id = $_SESSION['user']['id'];
// ... (Your corrected queries from the previous step go here) ...
$stmt = $mysqli->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$s = $stmt->get_result()->fetch_assoc();

if (!$s) { die('No student profile has been linked to your account.'); }

$student_id = $s['id'];
$totQ = $mysqli->prepare('SELECT COUNT(*) as c FROM attendance WHERE student_id = ?');
$totQ->bind_param('i', $student_id);
$totQ->execute();
$tot = $totQ->get_result()->fetch_assoc()['c'];

$presentQ = $mysqli->prepare("SELECT COUNT(*) as c FROM attendance WHERE student_id = ? AND (status='present' OR status='late')");
$presentQ->bind_param('i', $student_id);
$presentQ->execute();
$present = $presentQ->get_result()->fetch_assoc()['c'];

$percent = $tot > 0 ? round(($present / $tot) * 100, 2) : 0;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">My Dashboard</h4>
    <div class="row g-4">
        <div class="col-md-5">
            <div class="card p-3 text-center">
                <h6>Overall Attendance</h6>
                <h2 class="display-4"><?php echo $percent; ?>%</h2>
                <div class="progress mt-2" style="height: 10px;">
                    <div class="progress-bar" role="progressbar" style="width: <?php echo $percent; ?>%;" aria-valuenow="<?php echo $percent; ?>"></div>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card">
                <div class="card-header"><h5>Today's Status (<?php echo date("F j"); ?>)</h5></div>
                <div class="card-body">
                    <div id="realtime" class="fs-3 text-center p-3">Loading...</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Your real-time polling JavaScript from the previous step goes here
    async function pollStatus() {
        try {
            const response = await fetch('realtime_status.php');
            const data = await response.json();
            
            let statusHtml = `<span class="badge bg-secondary">Not Marked Yet</span>`;
            if (data.status) {
                if (data.status === 'present') statusHtml = `<span class="badge bg-success">PRESENT</span>`;
                else if (data.status === 'absent') statusHtml = `<span class="badge bg-danger">ABSENT</span>`;
                else if (data.status === 'late') statusHtml = `<span class="badge bg-warning text-dark">LATE</span>`;
            }
            document.getElementById('realtime').innerHTML = statusHtml;
        } catch (e) {
            document.getElementById('realtime').innerHTML = `<span class="badge bg-danger">Error fetching status</span>`;
        }
    }
    pollStatus(); // Initial call
    setInterval(pollStatus, 30000); // Poll every 30 seconds
</script>
</body>
</html>