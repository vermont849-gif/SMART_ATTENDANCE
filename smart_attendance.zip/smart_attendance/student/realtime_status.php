<?php
require '../config.php';
// require '../inc/functions.php';

// Set the content type to JSON for the response
header('Content-Type: application/json');

// Check if user is logged in and is a student
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'student') {
    // Send a JSON error and exit
    echo json_encode(['status' => null, 'error' => 'Not authenticated']);
    exit;
}

// Select the database
$mysqli->select_db('smart_attendance_upgraded');

$user_id = $_SESSION['user']['id'];
$today = date('Y-m-d');

// --- CORRECTED LOGIC ---
// Find the student's profile ID (from the students table) using their user_id.
$stmt_student = $mysqli->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
if (!$stmt_student) {
    echo json_encode(['status' => null, 'error' => 'Failed to prepare student query']);
    exit;
}
$stmt_student->bind_param('i', $user_id);
$stmt_student->execute();
$student_res = $stmt_student->get_result();

if ($student_res->num_rows === 0) {
    echo json_encode(['status' => null, 'error' => 'Student profile not found']);
    exit;
}
$student_id = $student_res->fetch_assoc()['id'];
$stmt_student->close();


// Now, check today's attendance status using the correct student ID
$stmt_status = $mysqli->prepare('SELECT status FROM attendance WHERE student_id = ? AND date = ? LIMIT 1');
if (!$stmt_status) {
    echo json_encode(['status' => null, 'error' => 'Failed to prepare attendance query']);
    exit;
}
$stmt_status->bind_param('is', $student_id, $today);
$stmt_status->execute();
$status_res = $stmt_status->get_result();

$status = null; // Default to null (which means "Not Marked Yet")
if ($status_res && $status_res->num_rows > 0) {
    $status = $status_res->fetch_assoc()['status'];
}
$stmt_status->close();


// Send the final status back as a JSON object
echo json_encode(['status' => $status, 'error' => null]);
?>