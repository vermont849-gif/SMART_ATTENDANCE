<?php
require '../config.php';
// ... your PHP code is fine ...
if (!isset($_SESSION['user']) || $_SESSION['user']['role']!=='student') { header('Location: ../index.php'); exit; }
$stmt = $mysqli->prepare('SELECT * FROM students WHERE user_id=? LIMIT 1'); $stmt->bind_param('i', $_SESSION['user']['id']); $stmt->execute(); $s = $stmt->get_result()->fetch_assoc();
$totQ = $mysqli->prepare('SELECT COUNT(*) as c FROM attendance WHERE student_id = ?'); $totQ->bind_param('i',$s['id']); $totQ->execute(); $tot = $totQ->get_result()->fetch_assoc()['c'];
$presentQ = $mysqli->prepare("SELECT COUNT(*) as c FROM attendance WHERE student_id = ? AND status IN ('present', 'late')"); $presentQ->bind_param('i',$s['id']); $presentQ->execute(); $present = $presentQ->get_result()->fetch_assoc()['c'];
$percent = $tot>0? round(($present/$tot)*100,2):0;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Attendance Certificate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
<div class="container text-center mt-5">
  <div class="p-5 border shadow-sm bg-white">
    <h2>Attendance Certificate</h2>
    <p class="lead">This is to certify that</p>
    <h3 class="my-3"><?php echo htmlspecialchars($s['name']); ?></h3>
    <p>(Roll No: <?php echo htmlspecialchars($s['roll_no']); ?>)</p>
    <p>has an attendance percentage of</p>
    <h1 class="display-4 text-primary"><?php echo $percent; ?>%</h1>
    <p class="text-muted">As of: <?php echo date('F j, Y'); ?></p>
    <div class="mt-4 d-print-none">
        <button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button>
        <a href="dashboard_student.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
  </div>
</div>
</body>
</html>