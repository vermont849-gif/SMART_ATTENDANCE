<?php
require '../config.php';
// ... your PHP code is fine ...
if (!isset($_SESSION['user']) || $_SESSION['user']['role']!=='student') { header('Location: ../index.php'); exit; }
$stmt = $mysqli->prepare('SELECT * FROM students WHERE user_id=? LIMIT 1'); $stmt->bind_param('i', $_SESSION['user']['id']); $stmt->execute(); $s = $stmt->get_result()->fetch_assoc();
if (!$s) { die('No profile found.'); }
$q = $mysqli->prepare('SELECT a.date, a.status, c.name as class_name FROM attendance a JOIN classes c ON a.class_id=c.id WHERE a.student_id=? ORDER BY a.date DESC'); $q->bind_param('i',$s['id']); $q->execute(); $res = $q->get_result();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Attendance History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">Full Attendance History</h4>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead><tr><th>Date</th><th>Class</th><th>Status</th></tr></thead>
                <tbody>
                    <?php while ($r = $res->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date("F j, Y", strtotime($r['date'])); ?></td>
                        <td><?php echo htmlspecialchars($r['class_name']); ?></td>
                        <td>
                            <?php
                                $status = $r['status'];
                                $badge = 'secondary';
                                if ($status == 'present') $badge = 'success';
                                if ($status == 'absent') $badge = 'danger';
                                if ($status == 'late') $badge = 'warning text-dark';
                                echo "<span class='badge bg-$badge'>" . ucfirst($status) . "</span>";
                            ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>