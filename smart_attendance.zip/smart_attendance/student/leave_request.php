<?php
require '../config.php';
// ... your PHP code is fine ...
if (!isset($_SESSION['user']) || $_SESSION['user']['role']!=='student') { header('Location: ../index.php'); exit; }
$stmt = $mysqli->prepare('SELECT id FROM students WHERE user_id=? LIMIT 1'); $stmt->bind_param('i', $_SESSION['user']['id']); $stmt->execute(); $s = $stmt->get_result()->fetch_assoc();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!verify_csrf($_POST['csrf'] ?? '')) die('Invalid CSRF');
    $from = $_POST['from_date']; $to = $_POST['to_date']; $reason = $_POST['reason'];
    $ins = $mysqli->prepare('INSERT INTO leave_requests (student_id,from_date,to_date,reason) VALUES (?,?,?,?)');
    $ins->bind_param('isss', $s['id'],$from,$to,$reason); $ins->execute();
    audit_log($mysqli, $_SESSION['user']['id'], 'leave_request', 'Leave from '.$from.' to '.$to);
    header('Location: dashboard_student.php?leave=1'); exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Leave Request</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card">
                <div class="card-header"><h4>Apply for Leave</h4></div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                        <div class="mb-3"><label class="form-label">From Date</label><input type="date" name="from_date" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">To Date</label><input type="date" name="to_date" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">Reason for Leave</label><textarea name="reason" class="form-control" rows="4" required></textarea></div>
                        <button class="btn btn-primary">Submit Request</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>