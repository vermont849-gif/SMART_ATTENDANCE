<?php
require '../config.php';
// require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'teacher') {
    header('Location: ../index.php');
    exit();
}

// Explicitly select the database
$mysqli->select_db('smart_attendance_upgraded');

$teacher_id = $_SESSION['user']['id'];
$classes_result = $mysqli->query("SELECT id, name FROM classes WHERE teacher_id = $teacher_id");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mark Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">Mark Attendance</h4>
    <div class="card">
        <div class="card-body">
            <form action="mark_attendance.php" method="post" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-5">
                        <label for="class_id" class="form-label">Select Class</label>
                        <select name="class_id" id="class_id" class="form-select" required>
                            <option value="">-- Select Your Class --</option>
                            <?php if ($classes_result) while ($row = $classes_result->fetch_assoc()): ?>
                                <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label for="date" class="form-label">Select Date</label>
                        <input type="date" name="attendance_date" id="date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" name="fetch_students" class="btn btn-primary w-100">Fetch Students</button>
                    </div>
                </div>
            </form>

            <?php
            if (isset($_POST['fetch_students'])) {
                $class_id = (int)$_POST['class_id'];
                $attendance_date = $_POST['attendance_date'];

                // ** THE FIX IS HERE: Use JOIN to get student names from the 'users' table **
                $query = "
                    SELECT s.id, u.name, s.roll_no 
                    FROM students s 
                    JOIN users u ON s.user_id = u.id 
                    WHERE s.class_id = ? 
                    ORDER BY u.name
                ";
                $stmt = $mysqli->prepare($query);
                
                // Add an error check for debugging
                if ($stmt === false) {
                    die("Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error);
                }

                $stmt->bind_param("i", $class_id); // <-- Line 53 will now work
                $stmt->execute();
                $students_result = $stmt->get_result();
            ?>
                <hr>
                <h5>Marking for <?php echo date("F j, Y", strtotime($attendance_date)); ?></h5>
                <form action="submit_attendance.php" method="post">
                    <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                    <input type="hidden" name="date" value="<?php echo $attendance_date; ?>">
                    <table class="table table-sm table-striped">
                        <thead><tr><th>Roll No.</th><th>Student Name</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php while ($s = $students_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($s['roll_no']); ?></td>
                                <td><?php echo htmlspecialchars($s['name']); ?></td>
                                <td>
                                    <input type="radio" class="btn-check" name="status[<?php echo $s['id']; ?>]" value="present" id="p-<?php echo $s['id']; ?>" autocomplete="off" required>
                                    <label class="btn btn-sm btn-outline-success" for="p-<?php echo $s['id']; ?>">Present</label>
                                    <input type="radio" class="btn-check" name="status[<?php echo $s['id']; ?>]" value="absent" id="a-<?php echo $s['id']; ?>" autocomplete="off" checked>
                                    <label class="btn btn-sm btn-outline-danger" for="a-<?php echo $s['id']; ?>">Absent</label>
                                    <input type="radio" class="btn-check" name="status[<?php echo $s['id']; ?>]" value="late" id="l-<?php echo $s['id']; ?>" autocomplete="off">
                                    <label class="btn btn-sm btn-outline-warning" for="l-<?php echo $s['id']; ?>">Late</label>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary">Submit Attendance</button>
                </form>
            <?php } // End of if(isset($_POST['fetch_students'])) ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>