<?php
require '../config.php';
// require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'teacher') {
    header('Location: ../index.php');
    exit;
}

$teacher_id = $_SESSION['user']['id'];
// ... (Your corrected queries from the previous step go here) ...
$total_students_query = $mysqli->prepare("SELECT COUNT(DISTINCT s.id) as c FROM students s JOIN classes c ON s.class_id = c.id WHERE c.teacher_id = ?");
$total_students_query->bind_param('i', $teacher_id);
$total_students_query->execute();
$total_students = $total_students_query->get_result()->fetch_assoc()['c'];

$today = date('Y-m-d');
$present_today_query = $mysqli->prepare("SELECT COUNT(*) as c FROM attendance a JOIN classes c ON a.class_id = c.id WHERE c.teacher_id = ? AND a.date = ? AND a.status = 'present'");
$present_today_query->bind_param('is', $teacher_id, $today);
$present_today_query->execute();
$present_today = $present_today_query->get_result()->fetch_assoc()['c'];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Teacher Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">Teacher Dashboard</h4>
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card text-center p-3">
                <h6>My Total Students</h6>
                <h3 class="display-4"><?php echo $total_students; ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center text-white bg-success p-3">
                <h6>Present Today (My Classes)</h6>
                <h3 class="display-4"><?php echo $present_today; ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h6 class="text-center">Quick Actions</h6>
                <div class="d-grid gap-2">
                    <a href="mark_attendance.php" class="btn btn-primary">Mark / Edit Attendance</a>
                    <a href="analytics.php" class="btn btn-outline-secondary">View Analytics</a>
                </div>
            </div>
        </div>
    </div>
    <!-- You can add charts or other info here -->
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>