<?php
require '../config.php';
// require '../inc/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'teacher') {
    header('Location: mark_attendance.php');
    exit;
}
// if (!verify_csrf($_POST['csrf'] ?? '')) { die('Invalid CSRF'); }

$date = $_POST['date'];
$class_id = (int)$_POST['class_id'];
$marked_by = $_SESSION['user']['id'];
$statuses = $_POST['status'] ?? [];

// IMPORTANT: We need a unique key on (student_id, date) in the attendance table for this to work.
// Run this SQL once in phpMyAdmin: ALTER TABLE `attendance` ADD UNIQUE `student_day_unique`(`student_id`, `date`);

$stmt = $mysqli->prepare("INSERT INTO attendance (student_id, class_id, date, status, marked_by) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)");

foreach ($statuses as $student_id => $status) {
    $student_id = (int)$student_id;
    $stmt->bind_param("iissi", $student_id, $class_id, $date, $status, $marked_by);
    $stmt->execute();
}

audit_log($mysqli, $marked_by, 'mark_attendance', "Marked attendance for class ID $class_id on $date");
header('Location: dashboard_teacher.php?success=1');
exit;
?>