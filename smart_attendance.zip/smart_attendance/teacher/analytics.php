<?php
require '../config.php';
// require '../inc/functions.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'teacher') {
    header('Location: ../index.php');
    exit;
}
$teacher_id = $_SESSION['user']['id'];

// --- CORRECTED LOGIC: Get stats ONLY for the teacher's classes ---
$labels = [];
$data = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $labels[] = date('M j', strtotime($d)); // More readable labels

    // Get total attendance records for THIS teacher's classes on a given day
    $totQ = $mysqli->prepare("SELECT COUNT(*) as c FROM attendance a JOIN classes c ON a.class_id=c.id WHERE a.date=? AND c.teacher_id=?");
    $totQ->bind_param('si', $d, $teacher_id);
    $totQ->execute();
    $tot = $totQ->get_result()->fetch_assoc()['c'];

    // Get present records for THIS teacher's classes on a given day
    $presQ = $mysqli->prepare("SELECT COUNT(*) as c FROM attendance a JOIN classes c ON a.class_id=c.id WHERE a.date=? AND a.status IN ('present', 'late') AND c.teacher_id=?");
    $presQ->bind_param('si', $d, $teacher_id);
    $presQ->execute();
    $pres = $presQ->get_result()->fetch_assoc()['c'];

    $data[] = $tot > 0 ? round(($pres / $tot) * 100, 2) : 0;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Attendance Analytics</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">My Classes: Attendance % (Last 7 days)</h4>
    <div class="card">
        <div class="card-body">
            <canvas id="chart" height="100"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const ctx = document.getElementById('chart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($labels); ?>,
        datasets: [{
            label: '% Present',
            data: <?php echo json_encode($data); ?>,
            borderColor: 'rgb(75, 192, 192)',
            fill: false,
            tension: 0.3
        }]
    }
});
</script>
</body>
</html>