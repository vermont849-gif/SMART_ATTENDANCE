<?php
require 'config.php';
if (!isset($_SESSION['user'])) { header('Location: index.php'); exit; }
$u = $_SESSION['user'];
if ($u['role']==='teacher') header('Location: teacher/dashboard_teacher.php');
if ($u['role']==='student') header('Location: student/dashboard_student.php');
if ($u['role']==='admin') header('Location: admin/dashboard_admin.php');
?>