# Smart Attendance - Upgraded PHP + MySQL (Demo)

This upgraded project includes:
- Secure authentication using `password_hash()`.
- CSRF protection tokens.
- Audit logging (`audit_log` table).
- Leave requests with approval workflow.
- Role-based access control (admin, teacher, student).
- Chart.js analytics for dashboards.
- Batch marking and quick actions.
- Export attendance as CSV (Excel-compatible).
- Printable attendance certificates (HTML printable view).
- Prepared statements throughout.

## Setup
1. Place this folder into your web server document root (e.g. XAMPP `htdocs`).
2. Edit `config.php` database credentials if needed.
3. Run `setup.php` once in browser (e.g. http://localhost/smart_attendance_php_upgraded/setup.php) to create the DB and seed admin/teacher/student with hashed passwords.
4. Login with seeded accounts:
   - Admin: admin@example.com / admin123
   - Teacher: teacher@example.com / teacher123
   - Student: student@example.com / student123
5. After setup, remove or secure `setup.php` (it will refuse to run twice).

Security note: This demo is improved but still simplified for education. Review before production deployment.
