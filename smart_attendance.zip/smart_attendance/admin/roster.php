<?php
require '../config.php';
// require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Explicitly select the database to ensure queries work
$mysqli->select_db('smart_attendance_upgraded');

// --- HANDLE ADD/REMOVE ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $class_id = (int)$_POST['class_id'];
    
    if (isset($_POST['add_student'])) {
        $student_id = (int)$_POST['student_id'];
        $stmt = $mysqli->prepare("UPDATE students SET class_id = ? WHERE id = ?");
        $stmt->bind_param('ii', $class_id, $student_id);
        $stmt->execute();
        audit_log($mysqli, $_SESSION['user']['id'], 'assign_student', "Assigned student ID $student_id to class ID $class_id");
    }
    
    if (isset($_POST['remove_student'])) {
        $student_id = (int)$_POST['student_id'];
        $stmt = $mysqli->prepare("UPDATE students SET class_id = NULL WHERE id = ?");
        $stmt->bind_param('i', $student_id);
        $stmt->execute();
        audit_log($mysqli, $_SESSION['user']['id'], 'unassign_student', "Unassigned student ID $student_id from class ID $class_id");
    }
    
    header("Location: roster.php?class_id=$class_id");
    exit;
}

// --- FETCH DATA FOR DISPLAY ---
$selected_class_id = (int)($_GET['class_id'] ?? 0);
$classes = $mysqli->query("SELECT id, name FROM classes ORDER BY name ASC");

$assigned_students = [];
$unassigned_students = [];

if ($selected_class_id > 0) {
    $stmt_assigned = $mysqli->prepare("
        SELECT s.id, u.name, s.roll_no 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        WHERE s.class_id = ? 
        ORDER BY u.name
    ");
    $stmt_assigned->bind_param('i', $selected_class_id);
    $stmt_assigned->execute();
    $assigned_result = $stmt_assigned->get_result();
    if ($assigned_result) {
        while ($row = $assigned_result->fetch_assoc()) {
            $assigned_students[] = $row;
        }
    }
}

$unassigned_result = $mysqli->query("
    SELECT s.id, u.name, s.roll_no 
    FROM students s 
    JOIN users u ON s.user_id = u.id 
    WHERE s.class_id IS NULL 
    ORDER BY u.name
");
if ($unassigned_result) {
    while ($row = $unassigned_result->fetch_assoc()) {
        $unassigned_students[] = $row;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Class Rosters</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">Manage Class Rosters</h4>

    <div class="card mb-4">
        <div class="card-body">
            <form method="get" action="roster.php">
                <div class="row align-items-end">
                    <div class="col-md-8">
                        <label for="class_id" class="form-label"><strong>Select a Class to Manage</strong></label>
                        <select name="class_id" id="class_id" class="form-select" onchange="this.form.submit()">
                            <option value="">-- Please Select a Class --</option>
                            <?php 
                            if ($classes):
                                while ($class = $classes->fetch_assoc()):
                            ?>
                                    <option value="<?php echo $class['id']; ?>" <?php if ($selected_class_id == $class['id']) echo 'selected'; ?>>
                                        <?php echo htmlspecialchars($class['name']); ?>
                                    </option>
                            <?php 
                                endwhile;
                            endif; // ** THIS IS THE FIX ** The missing endif for `if ($classes):`
                            ?>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if ($selected_class_id > 0): ?>
    <div class="row">
        <!-- Students in this Class Column -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h5>Students in this Class</h5></div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php if (count($assigned_students) > 0): ?>
                            <?php foreach ($assigned_students as $student): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><?php echo htmlspecialchars($student['name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($student['roll_no']); ?>)</small></span>
                                    <form method="post" action="roster.php" class="d-inline">
                                        <input type="hidden" name="class_id" value="<?php echo $selected_class_id; ?>">
                                        <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                                        <button type="submit" name="remove_student" class="btn btn-sm btn-outline-danger">Remove</button>
                                    </form>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="list-group-item text-muted">No students assigned to this class yet.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Unassigned Students Column -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h5>Unassigned Students</h5></div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php if (count($unassigned_students) > 0): ?>
                            <?php foreach ($unassigned_students as $student): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><?php echo htmlspecialchars($student['name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($student['roll_no']); ?>)</small></span>
                                    <form method="post" action="roster.php" class="d-inline">
                                        <input type="hidden" name="class_id" value="<?php echo $selected_class_id; ?>">
                                        <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                                        <button type="submit" name="add_student" class="btn btn-sm btn-outline-success">Add to Class</button>
                                    </form>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                             <li class="list-group-item text-muted">All students are assigned to a class.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>