<?php
require '../config.php';
// require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// --- HANDLE FORM SUBMISSIONS (CREATE/UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $password = $_POST['password'];
    $user_id = (int)($_POST['user_id'] ?? 0);

    $mysqli->begin_transaction();
    try {
        if ($user_id > 0) { // --- UPDATE USER ---
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, role=?, password=? WHERE id=?");
                $stmt->bind_param('ssssi', $name, $email, $role, $hashed_password, $user_id);
            } else {
                $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, role=? WHERE id=?");
                $stmt->bind_param('sssi', $name, $email, $role, $user_id);
            }
            $stmt->execute();

            // Update the student's roll number if the role is student
            if ($role === 'student' && isset($_POST['roll_no'])) {
                $roll_no = $_POST['roll_no'];
                // Use INSERT ... ON DUPLICATE KEY UPDATE to handle cases where a user is changed TO a student
                $stmt_student = $mysqli->prepare("INSERT INTO students (user_id, roll_no) VALUES (?, ?) ON DUPLICATE KEY UPDATE roll_no = VALUES(roll_no)");
                $stmt_student->bind_param('is', $user_id, $roll_no);
                $stmt_student->execute();
            }
            audit_log($mysqli, $_SESSION['user']['id'], 'update_user', "User email: $email");
        } else { // --- CREATE NEW USER ---
            if (empty($password)) throw new Exception("Password is required for new users.");
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt_user = $mysqli->prepare("INSERT INTO users (name, email, role, password) VALUES (?, ?, ?, ?)");
            $stmt_user->bind_param('ssss', $name, $email, $role, $hashed_password);
            $stmt_user->execute();
            $new_user_id = $mysqli->insert_id;
            
            if ($role === 'student') {
                $roll_no = $_POST['roll_no'];
                if (empty($roll_no)) throw new Exception("Roll Number is required for new students.");
                $stmt_student = $mysqli->prepare("INSERT INTO students (user_id, roll_no) VALUES (?, ?)");
                $stmt_student->bind_param('is', $new_user_id, $roll_no);
                $stmt_student->execute();
            }
            audit_log($mysqli, $_SESSION['user']['id'], 'create_user', "User email: $email");
        }
        $mysqli->commit();
    } catch (Exception $e) {
        $mysqli->rollback();
        die("Error: " . $e->getMessage());
    }
    header('Location: users.php');
    exit;
}

// --- HANDLE DELETE ---
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    if ($user_id !== $_SESSION['user']['id']) {
        $mysqli->begin_transaction();
        try {
            // Delete the student profile first (foreign key dependency)
            $stmt_student_del = $mysqli->prepare("DELETE FROM students WHERE user_id = ?");
            $stmt_student_del->bind_param('i', $user_id);
            $stmt_student_del->execute();
            
            // Then delete the user login
            $stmt_user_del = $mysqli->prepare("DELETE FROM users WHERE id=?");
            $stmt_user_del->bind_param('i', $user_id);
            $stmt_user_del->execute();
            
            $mysqli->commit();
            audit_log($mysqli, $_SESSION['user']['id'], 'delete_user', "Deleted user ID: $user_id");
        } catch (Exception $e) {
            $mysqli->rollback();
            die("Error deleting user: " . $e->getMessage());
        }
    }
    header('Location: users.php');
    exit;
}

// --- FETCH DATA FOR DISPLAY ---
$users = $mysqli->query('SELECT id, name, email, role FROM users ORDER BY created_at DESC');

// Fetch user data if editing
$edit_user = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $mysqli->prepare("SELECT u.id, u.name, u.email, u.role, s.roll_no FROM users u LEFT JOIN students s ON u.id = s.user_id WHERE u.id = ?");
    $stmt->bind_param('i', $edit_id);
    $stmt->execute();
    $edit_user = $stmt->get_result()->fetch_assoc();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <div class="row">
        <!-- User List Column -->
        <div class="col-md-8">
            <h4 class="mb-4">User List</h4>
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php while ($user = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><span class="badge bg-primary"><?php echo ucfirst($user['role']); ?></span></td>
                                <td>
                                    <a href="users.php?edit=<?php echo $user['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="users.php?delete=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure? This will also delete their student profile.');">Delete</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Add/Edit Form Column -->
        <div class="col-md-4">
            <h4 class="mb-4"><?php echo $edit_user ? 'Edit User' : 'Add New User'; ?></h4>
            <div class="card">
                <div class="card-body">
                    <form method="post" action="users.php">
                        <input type="hidden" name="user_id" value="<?php echo $edit_user['id'] ?? 0; ?>">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($edit_user['name'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($edit_user['email'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select name="role" id="roleSelector" class="form-select" required>
                                <option value="student" <?php if (isset($edit_user) && $edit_user['role'] === 'student') echo 'selected'; ?>>Student</option>
                                <option value="teacher" <?php if (isset($edit_user) && $edit_user['role'] === 'teacher') echo 'selected'; ?>>Teacher</option>
                                <option value="admin" <?php if (isset($edit_user) && $edit_user['role'] === 'admin') echo 'selected'; ?>>Admin</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="rollNoField">
                            <label class="form-label">Roll Number</label>
                            <input type="text" name="roll_no" class="form-control" value="<?php echo htmlspecialchars($edit_user['roll_no'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" <?php if (!$edit_user) echo 'required'; ?>>
                            <?php if ($edit_user): ?>
                                <small class="form-text text-muted">Leave blank to keep current password.</small>
                            <?php endif; ?>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary"><?php echo $edit_user ? 'Update User' : 'Add User'; ?></button>
                            <?php if ($edit_user): ?>
                                <a href="users.php" class="btn btn-secondary mt-2">Cancel Edit</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const roleSelector = document.getElementById('roleSelector');
    const rollNoField = document.getElementById('rollNoField');

    function toggleRollNoField() {
        if (roleSelector.value === 'student') {
            rollNoField.style.display = 'block';
            rollNoField.querySelector('input').required = true;
        } else {
            rollNoField.style.display = 'none';
            rollNoField.querySelector('input').required = false;
        }
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        toggleRollNoField(); // Run on page load to set initial state
        roleSelector.addEventListener('change', toggleRollNoField); // Run when role is changed
    });
</script>
</body>
</html>