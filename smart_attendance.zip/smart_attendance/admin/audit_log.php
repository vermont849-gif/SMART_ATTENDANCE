<?php
require '../config.php';
// require '../inc/functions.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$res = $mysqli->query('SELECT al.*, u.name as user_name FROM audit_log al LEFT JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC LIMIT 500');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Audit Log</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../includes/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">Audit Log</h4>
    <div class="card">
        <div class="card-body">
            <table class="table table-sm table-striped table-hover">
                <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Details</th></tr></thead>
                <tbody>
                    <?php while ($r = $res->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $r['created_at']; ?></td>
                        <td><?php echo htmlspecialchars($r['user_name'] ?? 'System'); ?></td>
                        <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($r['action']); ?></span></td>
                        <td><?php echo htmlspecialchars($r['details']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>