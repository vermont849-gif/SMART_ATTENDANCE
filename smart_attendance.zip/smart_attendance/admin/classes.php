<?php
require '../config.php';
// require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// --- HANDLE FORM SUBMISSIONS (CREATE/UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $teacher_id = (int)$_POST['teacher_id'];
    $class_id = (int)($_POST['class_id'] ?? 0);

    if ($class_id > 0) { // --- UPDATE CLASS ---
        $stmt = $mysqli->prepare("UPDATE classes SET name=?, description=?, teacher_id=? WHERE id=?");
        $stmt->bind_param('ssii', $name, $description, $teacher_id, $class_id);
        $action = 'update_class';
    } else { // --- CREATE NEW CLASS ---
        $stmt = $mysqli->prepare("INSERT INTO classes (name, description, teacher_id) VALUES (?, ?, ?)");
        $stmt->bind_param('ssi', $name, $description, $teacher_id);
        $action = 'create_class';
    }
    
    if ($stmt->execute()) {
        audit_log($mysqli, $_SESSION['user']['id'], $action, "Class name: $name");
    } else {
        echo "Error: " . $stmt->error;
    }
    header('Location: classes.php');
    exit;
}

// --- HANDLE DELETE ---
if (isset($_GET['delete'])) {
    $class_id = (int)$_GET['delete'];
    // Be careful with delete! You might want to prevent deleting classes with enrolled students.
    // For now, we'll allow it.
    $stmt = $mysqli->prepare("DELETE FROM classes WHERE id=?");
    $stmt->bind_param('i', $class_id);
    $stmt->execute();
    audit_log($mysqli, $_SESSION['user']['id'], 'delete_class', "Deleted class ID: $class_id");
    header('Location: classes.php');
    exit;
}

// --- FETCH DATA FOR DISPLAY ---
// We use a LEFT JOIN to get the teacher's name as well
$classes = $mysqli->query('
    SELECT c.id, c.name, c.description, u.name as teacher_name 
    FROM classes c 
    LEFT JOIN users u ON c.teacher_id = u.id 
    ORDER BY c.name ASC
');

// Fetch all users with the 'teacher' role for the dropdown menu
$teachers = $mysqli->query("SELECT id, name FROM users WHERE role = 'teacher' ORDER BY name ASC");

// Fetch class data if editing
$edit_class = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $mysqli->prepare("SELECT id, name, description, teacher_id FROM classes WHERE id = ?");
    $stmt->bind_param('i', $edit_id);
    $stmt->execute();
    $edit_class = $stmt->get_result()->fetch_assoc();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Classes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <div class="row">
        <!-- Class List Column -->
        <div class="col-md-8">
            <h4 class="mb-4">Class List</h4>
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead><tr><th>Class Name</th><th>Assigned Teacher</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php while ($class = $classes->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($class['name']); ?></td>
                                <td><?php echo htmlspecialchars($class['teacher_name'] ?? 'N/A'); ?></td>
                                <td>
                                    <a href="classes.php?edit=<?php echo $class['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="classes.php?delete=<?php echo $class['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this class?');">Delete</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Add/Edit Form Column -->
        <div class="col-md-4">
            <h4 class="mb-4"><?php echo $edit_class ? 'Edit Class' : 'Add New Class'; ?></h4>
            <div class="card">
                <div class="card-body">
                    <form method="post" action="classes.php">
                        <input type="hidden" name="class_id" value="<?php echo $edit_class['id'] ?? 0; ?>">
                        <div class="mb-3">
                            <label class="form-label">Class Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($edit_class['name'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($edit_class['description'] ?? ''); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Assign Teacher</label>
                            <select name="teacher_id" class="form-select" required>
                                <option value="">-- Select a Teacher --</option>
                                <?php while ($teacher = $teachers->fetch_assoc()): ?>
                                    <option value="<?php echo $teacher['id']; ?>" <?php if(isset($edit_class) && $edit_class['teacher_id'] == $teacher['id']) echo 'selected'; ?>>
                                        <?php echo htmlspecialchars($teacher['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary"><?php echo $edit_class ? 'Update Class' : 'Add Class'; ?></button>
                            <?php if ($edit_class): ?>
                                <a href="classes.php" class="btn btn-secondary mt-2">Cancel Edit</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>