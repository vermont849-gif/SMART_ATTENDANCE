<?php
require '../config.php';
require '../inc/functions.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role']!=='admin') { header('Location: ../index.php'); exit; }
$mysqli->select_db('smart_attendance_upgraded');
$id = intval($_GET['id'] ?? 0);
$upd = $mysqli->prepare('UPDATE leave_requests SET status="approved", reviewed_by=? WHERE id=?'); $upd->bind_param('ii', $_SESSION['user']['id'], $id); $upd->execute();
audit_log($mysqli, $_SESSION['user']['id'], 'approve_leave', 'Approved leave id '.$id);
header('Location: dashboard_admin.php'); exit;
?>