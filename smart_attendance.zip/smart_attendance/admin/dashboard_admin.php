<?php
require '../config.php';
// require '../inc/functions.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Select the database to ensure queries work
$mysqli->select_db('smart_attendance_upgraded');

$users = $mysqli->query('SELECT * FROM users ORDER BY created_at DESC LIMIT 10');

// --- CORRECTED QUERY ---
// We now JOIN through students to the users table to get the correct name.
$leaves_query = "
    SELECT lr.*, u.name as student_name 
    FROM leave_requests lr 
    JOIN students s ON lr.student_id = s.id 
    JOIN users u ON s.user_id = u.id 
    WHERE lr.status = 'pending'
";
$leaves = $mysqli->query($leaves_query);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include '../inc/navbar.php'; ?>

<div class="container py-4">
    <h4 class="mb-4">Admin Panel</h4>
    <div class="row g-4">
        <div class="col-md-7">
            <div class="card">
                <div class="card-header"><h5>Recent Users</h5></div>
                <div class="card-body">
                    <table class="table table-sm table-striped">
                        <thead><tr><th>Name</th><th>Email</th><th>Role</th></tr></thead>
                        <tbody>
                            <?php if ($users) while($u = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($u['name']); ?></td>
                                <td><?php echo htmlspecialchars($u['email']); ?></td>
                                <td><span class="badge bg-secondary"><?php echo $u['role']; ?></span></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card">
                <div class="card-header"><h5>Pending Leave Requests</h5></div>
                <div class="card-body">
                    <?php 
                    // ** THE FIX IS HERE **
                    // We check if the query was successful AND if it returned any rows.
                    if ($leaves && $leaves->num_rows > 0): 
                    ?>
                        <table class="table table-hover">
                            <thead><tr><th>Student</th><th>Dates</th><th>Action</th></tr></thead>
                            <tbody>
                                <?php while($l = $leaves->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($l['student_name']); ?></td>
                                    <td><?php echo date("M j", strtotime($l['from_date'])) . ' - ' . date("M j", strtotime($l['to_date'])); ?></td>
                                    <td>
                                        <a href="approve_leave.php?id=<?php echo $l['id']; ?>" class="btn btn-sm btn-success">✓</a>
                                        <a href="reject_leave.php?id=<?php echo $l['id']; ?>" class="btn btn-sm btn-danger">✗</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center text-muted">No pending leave requests.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>