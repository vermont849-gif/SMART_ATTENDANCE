<?php
require 'config.php';
require 'inc/functions.php';
login_required();
$mysqli->select_db('smart_attendance_upgraded');
$from = $_GET['from'] ?? null; $to = $_GET['to'] ?? null;
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="attendance_export.csv"');
$out = fopen('php://output','w');
fputcsv($out, ['student','roll','date','status']);
if ($from && $to) {
    $stmt = $mysqli->prepare('SELECT s.name,s.roll_no,a.date,a.status FROM attendance a JOIN students s ON a.student_id=s.id WHERE a.date BETWEEN ? AND ? ORDER BY a.date DESC');
    $stmt->bind_param('ss',$from,$to); $stmt->execute(); $res = $stmt->get_result();
} else {
    $res = $mysqli->query('SELECT s.name,s.roll_no,a.date,a.status FROM attendance a JOIN students s ON a.student_id=s.id ORDER BY a.date DESC LIMIT 1000');
}
while($r = $res->fetch_assoc()) fputcsv($out, [$r['name'],$r['roll_no'],$r['date'],$r['status']]);
fclose($out);
exit;
?>